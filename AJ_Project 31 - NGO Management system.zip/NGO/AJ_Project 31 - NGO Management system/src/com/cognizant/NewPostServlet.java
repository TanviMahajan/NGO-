package com.cognizant;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.util.Enumeration;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class NewPostServlet
 */
@WebServlet("/NewPostServlet")
public class NewPostServlet extends HttpServlet {
	static Connection con;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewPostServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	ServletContext context=getServletContext();
	String dirName=context.getRealPath("//");
System.out.println(dirName);
	String parameter=null;
	String title="",cg="",dt="",add="",ct="",des="",mail="";
    int zc = 0;
	File file1=null;
	long size=0;
	String filePath="";
	try
	{
		MultipartRequest multi=new MultipartRequest(request,dirName, 10*1024*1024);
		Enumeration e=multi.getParameterNames();
		while(e.hasMoreElements())
		{
			parameter=(String)e.nextElement();
			if(parameter.equals("title"))
		     	title=multi.getParameter(parameter);
			
			if(parameter.equals("category"))
			    cg=multi.getParameter(parameter);
			
			if(parameter.equals("date of post"))
			   dt=multi.getParameter(parameter);
			
			if(parameter.equals("add"))
			   add=multi.getParameter(parameter);
			
			if(parameter.equals("state"))
		     	ct=multi.getParameter(parameter);
			
			if(parameter.equals("zip"))
			    zc=Integer.parseInt(multi.getParameter(parameter));
			
			if(parameter.equals("desc"))
			    des=multi.getParameter(parameter);
			if(parameter.equals("email"))
			    mail=multi.getParameter(parameter);
	     }
		
		Enumeration files=multi.getFileNames();
		while(files.hasMoreElements())
		{
			parameter=(String)files.nextElement();
			if(parameter.equalsIgnoreCase("picture"))
			{
			    filePath=multi.getFilesystemName(parameter);
			    String final_filePath=dirName+"\\"+filePath;
			    System.out.println(final_filePath);
			    file1=new File(final_filePath);
			    size=file1.length();
				FileInputStream finput=new FileInputStream(file1);
				FileOutputStream fout=new FileOutputStream(new File("C:\\Users\\764973\\NGO"+filePath));
			      System.out.println("ok");
				int j=0;
				while((j=finput.read())!=-1)
				{
		fout.write((byte)j);
				}
				finput.close();
				fout.close();
				
			}
			
			Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "root");
			  PreparedStatement ps=con.prepareStatement("insert into Post values(?,?,?,?,?,?,?,?,?) ");
			  ps.setString(1,title);
			  ps.setString(2,cg);
			  ps.setString(3,dt);
			  ps.setString(4,add);
			  ps.setString(5,ct);
			  ps.setInt(6,zc);
			  ps.setString(7,filePath);
			  ps.setString(8,des);
			  ps.setString(9,mail);
			  int i=ps.executeUpdate();
				if(i>0)
				{
					out.print("<script>window.alert('Details saved')</script>");
					RequestDispatcher rd=request.getRequestDispatcher("WelcomeUser.jsp");
					rd.include(request,response);
				}
		}
		}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}
	}
